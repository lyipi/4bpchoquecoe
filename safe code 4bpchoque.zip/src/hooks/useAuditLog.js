// useAuditLog hook has been removed as requested.
// This file is kept as a dummy export to satisfy build requirements without functionality.
export const useAuditLog = () => ({ logAction: async () => {} });